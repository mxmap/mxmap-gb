
import commands.TlsHttpCertCheck
import commands.TlsSmtpCertCheck
import models.enums.TlsCertError
import org.junit.Assert.*
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.runner.RunWith
import org.junit.runners.Parameterized
import java.lang.Thread.sleep

@RunWith(Parameterized::class)
class TLSTests(private val domain: String) {

    companion object {
        // 3. Diese Methode liefert die Testdaten
        @JvmStatic
        @Parameterized.Parameters(name = "{index}: Teste Server {0}")
        fun data(): Collection<Array<String>> {
            return listOf(
                arrayOf("prefilter.emailsecurity.trendmicro.eu"),
                arrayOf("mail.bolsover.gov.uk"),
                arrayOf("mailgate.derbyshiredales.gov.uk"),

                arrayOf("uk.mx1.mailanyone.net"), // G
                arrayOf("uk.mx3.mailanyone.net"), // G

                arrayOf("mailgate.ne-derbyshire.gov.uk"),

                arrayOf("uk.mx2.mx25.net"), // G

                arrayOf("pop3.positive-internet.com"), // G UG


                arrayOf("mail.charnwood.gov.uk"),
                arrayOf("mail3.redditchbc.gov.uk"),

                arrayOf("mx3.westlothian.gov.uk") // G
                // Hier kannst du beliebig viele weitere Domains als arrayOf("...") hinzufügen
            )
        }
    }

    // 4. Dein eigentlicher Testfall
    @Test
    fun checkTLSSmtpTestResoladed() {
        sleep(1)
        val smtpCheck = TlsSmtpCertCheck(domain)
        val ret = smtpCheck.testSmtpTlsHandshake()

        println("Ergebnis für $domain: ${ret?.errorType}")

        // Achtung: In JUnit 4 steht die Custom-Fehlermeldung ganz VORNE!
        assertEquals("Fehler bei der Domain $domain: ${ret?.errorType}", null, ret?.errorType)
    }



    @Test
    fun checkHttpTLSVersion() {
        val httpCheck = TlsHttpCertCheck("badssl.com", "104.154.89.105")
        val ret = httpCheck.testHttpsTlsHandshake()
        assertEquals("TLSv1.2", ret?.tlsVersion)
    }


    @Test
    fun checkHttpExpiredCertificate() {
        val httpCheck = TlsHttpCertCheck("expired.badssl.com","104.154.89.105")
        val ret = httpCheck.testHttpsTlsHandshake()
        assertEquals(TlsCertError.ExpiredCertificate.stringText,ret?.errorType)
    }

    @Test
    fun checkTLSSmtpTest() {
        val smtpCheck = TlsSmtpCertCheck("gmail-smtp-in.l.google.com")
        val ret = smtpCheck.testSmtpTlsHandshake()
        println(ret?.errorType)
        assertEquals(null, ret?.errorType)
    }




    @Test
    fun testuntrustedRoot() {
        val httpsCheck = TlsHttpCertCheck("untrusted-root.badssl.com")
        val ret = httpsCheck.testHttpsTlsHandshake()
        assertEquals(TlsCertError.RootCAUntrusted.stringText, ret?.errorType)
        println(TlsCertError.RootCAUntrusted.stringText)
    }

    @Test
    fun noConnectionRoot() {
        val httpsCheck = TlsHttpCertCheck("localhost")
        val ret = httpsCheck.testHttpsTlsHandshake()
        assertEquals(TlsCertError.SocketVerbindungsfehler.stringText.startsWith(TlsCertError.SocketVerbindungsfehler.stringText), ret?.errorType?.startsWith(TlsCertError.SocketVerbindungsfehler.stringText))
    }

    @Test
    fun selfSigned() {
        val httpsCheck = TlsHttpCertCheck("self-signed.badssl.com")
        val ret = httpsCheck.testHttpsTlsHandshake()
        assertEquals(TlsCertError.RootCAUntrusted.stringText, ret?.errorType)
    }

    @Test
    fun incompleteChain() {
        val httpsCheck = TlsHttpCertCheck("incomplete-chain.badssl.com")
        val ret = httpsCheck.testHttpsTlsHandshake()
        assertEquals(TlsCertError.RootCAUntrusted.stringText, ret?.errorType)
    }

    @Test
    fun mismatchHost() {
        val httpsCheck = TlsHttpCertCheck("wrong.host.badssl.com")
        val ret = httpsCheck.testHttpsTlsHandshake()
        assertEquals(TlsCertError.SANMismatch.stringText, ret?.errorType)
    }

}