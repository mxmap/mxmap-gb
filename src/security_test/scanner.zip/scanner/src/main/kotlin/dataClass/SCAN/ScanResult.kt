package dataClass.SCAN

import dataClass.DKIM.DKIMResult
import dataClass.DMARC.DMARCPolicy
import dataClass.DNSSEC.DNSSECResult
import dataClass.MTASTS.MtaStsDnsRecordResult
import dataClass.MTASTS.MtaStsPolicy
import dataClass.SPF.SPFResult
import dataClass.TLS.TLSDataCollector
import dataClass.TLS.TLS_1_2_AllResult
import dataClass.TLS.TlsRptDnsRecordResult
import kotlinx.datetime.Instant
import kotlinx.serialization.Serializable
import models.DaneCheckResult
import models.DssResult
import models.TestSSLResult

@Serializable
data class ScanResult(

    val scanTime: Instant,
    val scanData: List<ScanData>,


    val tlsCertTest : List<TLSDataCollector>,
    val testSSLResult: List<TestSSLResult>,
    val tls12Test : List<TLS_1_2_AllResult>,

   // val dssResult: List<DssResult>,
    val dmarcResult: List<DMARCPolicy>,
    val spfResult: List<SPFResult>,
    val dkimResult: List<DKIMResult>,


    val dnssecDomain: List<DNSSECResult>,
    val dnssecMX: List<DNSSECResult>,

    val daneCheckResult: List<DaneCheckResult>,

    val mtaStsDnsRecordResult: List<MtaStsDnsRecordResult>,
    val mtaStsPolicyResult: List<MtaStsPolicy>,

    val tlsRptDnsRecordResult: List<TlsRptDnsRecordResult>


)