package dataClass.TLS

data class tlsRequirements(val version: String, val cipherSuite: String,
                           val curvesData: Array<String>, val signatureAlgorithms: Array<String>)