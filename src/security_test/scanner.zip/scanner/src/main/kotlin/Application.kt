import dataClass.SCAN.ScanDataNotNullable
import dataClass.SCAN.ScanResult
import dataClass.SCAN.ScanResultProvider
import kotlinx.datetime.Clock
import kotlinx.serialization.json.Json
import org.slf4j.LoggerFactory
import java.io.File
import kotlin.div

class Application

fun main() {
    System.setProperty(org.slf4j.impl.SimpleLogger.DEFAULT_LOG_LEVEL_KEY, Config["LOG_LEVEL"]);

    val inputDirectory = File("./scanner-input")
    inputDirectory.listFiles { file -> file.isFile && file.extension.lowercase() == "json" }?.forEach { file ->

        // 1. Scan über alle in der Datei stehenden Domains
        val fileName = file.nameWithoutExtension
        val domains = Preprocessing.loadUniqueDomainsFromMailList(file.absolutePath)
        val dmarcReportingDomains = executeTestOnDomains(domains, fileName)

        // 2. Scan über alle im ersten Scan erfassten externen DMARC-Reporting-Adressen
        val fileNameExternalReporting = "ext${file.nameWithoutExtension}_extDMARC"
        executeTestOnDomains(dmarcReportingDomains, fileNameExternalReporting)
    }

}


fun executeTestOnDomains(domains: List<String>, outputJSONName: String): List<String> {

    val logger = LoggerFactory.getLogger(Application::class.java)
    val startTime = System.currentTimeMillis()
    logger.info("starting security scan for $outputJSONName")


    logger.info("loaded ${domains.size} unique domains from " + outputJSONName)

    val mxRecords = Preprocessing.resolveMXRecords(domains)
    val uniqueMXRecords = mxRecords.distinctBy { it.mxRecord }
    logger.info("loaded ${uniqueMXRecords.size} unique mx records")

    val scanData = Preprocessing.resolveIPAddresses(mxRecords)


    logger.info("loaded ${scanData.size} unique combinations of domain + mx + ip")
    val uniqueMXAndIP =
        scanData.distinctBy { it.mxRecord + it.ipAddress }.filter { it.mxRecord != null && it.ipAddress != null }
            .map { ScanDataNotNullable(it.domain, it.mxRecord!!, it.ipAddress!!) }
    logger.info("loaded ${uniqueMXAndIP.size} unique combinations of mx + ip")

    // Key Mailserver -> Value: (Menge an zugehörigen IPs)
    val groupedMX = uniqueMXAndIP.groupBy { it.mxRecord }
    val maxIpsForAnyMx = groupedMX.values.maxOfOrNull { it.size } ?: 0

    val interleavedScanList = mutableListOf<ScanDataNotNullable>()

    // Round-Robin  -> Verteile die MX-Hosts: nimm im ersten durchlauf jeweils die erste IP von jedem Mailserver
    // Im zweiten Durchlauf die zweite IP von jedem Mailserver usw.
    for (i in 0 until maxIpsForAnyMx) {
        for (mxList in groupedMX.values) {
            if (i < mxList.size) {
                interleavedScanList.add(mxList[i])
            }
        }
    }

    val mxRecordsNotNull = mxRecords.filter { it.mxRecord != null }.map { it.mxRecord!! }.distinct()
    val scanTime = Clock.System.now()



    // Neue Tests sind ausgelagert in Kotlin-Object "Measurement", wird noch ueberarbeitet
    val smtpCertTlsResults = Measurement.mxTlsCertTest(mxRecordsNotNull)
    val mtaStsDnsRecordResults = Measurement.mtaStsDnsRecordTest(domains)
    // Frage nur die MTA-STS-Policy ab für die Domains, wo unter _mta-sts. ein TXT-Eintrag liegt
    val mtaStsPolicyResults = Measurement.mtaStsPolicyTest(mtaStsDnsRecordResults)
    val tlsRptDnsResults =  Measurement.tlsRptDnsRecordTest(domains)//Measurement.tlsRptDnsRecordTest(domains)



    //Bisherige Tests sind ebenfalls ausgelagert
    //val dssResults = Measurement.dssTest(domains)

    val testSSLResults = Measurement.tlsVersionRangeTest(uniqueMXAndIP)
    val daneMxResults = Measurement.daneMxTest(mxRecordsNotNull)

    val dmarcResults = Measurement.dmarcTest(domains)

    val dkimResults = Measurement.dkimTest(domains)
    val spfResults = Measurement.spfTest(domains)

    // DNSSEC für jede Domain testen
    val dnssecDomain = Measurement.dnssecTestDomain(mxRecords)

    // DNSSEC für jeden MX-Host testen
    val dnssecMX = Measurement.dnssecTestMXHosts(scanData)

    val tls_1_2_Results = Measurement.testTLS_1_2Config(mxRecordsNotNull)

    val scanResult = ScanResult(

        scanTime,
        scanData,

        smtpCertTlsResults,
        testSSLResults,
        tls_1_2_Results,


        dmarcResults.dmarcResults,
        spfResults,
        dkimResults,

        dnssecDomain,
        dnssecMX,

        daneMxResults,
        mtaStsDnsRecordResults,
        mtaStsPolicyResults,
        tlsRptDnsResults,


        )
    logger.info("security scan for $outputJSONName finished")
    logger.info("total scan time for $outputJSONName is: ${"%.2f".format((System.currentTimeMillis() - startTime) / 1000.0)} seconds")

    val jsonFormatter = Json { prettyPrint = true; encodeDefaults = true }
    val scanResultJSON = jsonFormatter.encodeToString(ScanResult.serializer(), scanResult)
    writeJSONFile(scanResultJSON, "./scanner-result/"+ outputJSONName +"_scanResult.json")

    // Rückgabe aller erfassten externen DMARC-Reporting-Domains
    val domainsExternalDmarcReporting = dmarcResults.externalDomains.distinct()
    return domainsExternalDmarcReporting
}


fun writeJSONFile(content: String, fileName: String) {
    val outFile = File(fileName)
    outFile.writeText(content)
}



