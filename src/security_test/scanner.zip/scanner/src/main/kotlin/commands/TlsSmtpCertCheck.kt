package commands

import dataClass.TLS.tlsRequirements
import dataClass.TLS.TLSDataCollector
import models.enums.TlsCertError
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Socket

class TlsSmtpCertCheck( hostname: String, ip: String? = null ): TLS( 25 ,hostname, ip){

    // Zunächst im Klartext: Ermittle dessen Unterstützung und sende den STARTTLS-Befehl
    public fun testSmtpTlsHandshake(tlsRequirements: tlsRequirements? = null) : TLSDataCollector? {
        var socket: Socket? = null
        try{

            val usedHostname = ip ?: hostname
            socket = Socket(usedHostname, 25)
            socket.soTimeout = 40000

            val reader = BufferedReader(InputStreamReader(socket.inputStream)) //Netzwerbytes -> Text lesbar
            val writer = PrintWriter(socket.outputStream, true) // Client -> Server autoFlush, bei jedem LineBreak

            // 1. SMTP Handshake lesen
            var response = readSmtpResponse(reader) // Netzwerkbytes umwandeln in lesbaren Text
            //println("Server: \n" + response)

            if (response == null || !response.trim().startsWith("220")) {
                closeSMTPSession(socket,writer)
                return TLSDataCollector(
                    hostname, ip, null, null, null,
                    TlsCertError.SmtpErrorNoGreetingReply.stringText
                )
            }

            // EHLO senden
            //println("EHLO "+ InetAddress.getLocalHost().hostName + "\r\n")
            writer.print("EHLO "+ "mail-sicherheit-test.de" + "\r\n")
            writer.flush() // Schickt gebufferte Bytes ab
            response = readSmtpResponse(reader)
            //println("Server : \n" + response)

            if(response == null ) {

                closeSMTPSession(socket,writer)
                return TLSDataCollector(
                    hostname,ip, null, null, null,
                    TlsCertError.SmtpErrorNoEHLO.stringText
                )

            }else if(!response.trim().contains("STARTTLS")) {

                closeSMTPSession(socket,writer)
                return TLSDataCollector(
                    hostname ,ip, null, null, null,
                    TlsCertError.SmtpErrorNoSTARTTLSOffered.stringText
                )

            }


            // STARTTLS gemäß RFC 3207 Kap.4 anfordern
            writer.print("STARTTLS\r\n")
            writer.flush()
            response = readSmtpResponse(reader)
            //println("Server : \n" + response)

            // Server MUSS gemäß RFC mit 220 antworten
            if (response == null || !response.trim().startsWith("220")) {

                closeSMTPSession(socket,writer)
                return TLSDataCollector(
                    hostname,ip, null, null, null,
                    TlsCertError.SmtpErrorSTARTTLS.stringText
                )
            }

            // STarte nun den (allgemeinen) TLS-Handshake
            return testTLS(socket, tlsRequirements)

        } catch(e : Exception){
            if(socket != null && !socket.isClosed()) {
                runCatching {
                    socket?.close()
                }
            }


            // Den Namen der Exception-Klasse holen
            val errorType = e::class.simpleName ?: "UnbekannteException"

            // Einen sinnvollen Fehlertext zusammenbauen
            val errorMessage = if (e.message.isNullOrBlank()) {
                errorType // Wenn keine Message da ist, nur den Typ ausgeben
            } else {
                "$errorType: ${e.message}" // Ansonsten Typ und Message
            }

            return TLSDataCollector(hostname, ip, null, null,
                null, "${TlsCertError.SocketVerbindungsfehler.stringText}: $errorMessage ")
        }
    }



    // Sende den QUIT-Command und schließe den Socket
    fun closeSMTPSession(socket: Socket, writer: PrintWriter) {
        //println("Fehler! Sende QUIT Command und schließe Socket")
        writer.print("QUIT\r\n")
        writer.flush()
        socket.close()
    }

    // Hilfsfunktion zum Lesen der mehrzeiligen SMTP-Antworten -> EHLO z.B.
    // Null -> Fehlerfall aufgetreten
    fun readSmtpResponse(reader: BufferedReader): String? {
        val response = StringBuilder() // Zusammenkleben
        var line: String //
        do {
            // ?: Wenn das linke Ergebnis null ist -> break durch ?:
            line = reader.readLine() ?: return null  // ?: break Kommt nichts -> Abbruch

            // Abbruch bei nicht positivem Reply-Code
            if (line.trim().startsWith("4") || line.trim().startsWith("5")) {
                println("Fehler! Der Server meldet einen Fehlercode: $line")
                return null
            }

            // Baue die Antwort als einen einzigen String zusammen
            response.append(line).append("\n")

            // letzte Zeile von EHLO-Extension ohne Bindestrich RFC, Starttls und Greeting Reply
        }while(!(line.length >= 4 && line[3] == ' '))

        return response.toString() // Zu String konvertieren
    }


}