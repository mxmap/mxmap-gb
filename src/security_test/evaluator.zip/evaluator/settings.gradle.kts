rootProject.name = "emailtest.evaluator"
