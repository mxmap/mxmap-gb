package emailtest

class ApplicationTest {
}