import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Socket
import java.security.cert.X509Certificate
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

fun main() {
    println("🚀 Starte isolierten STARTTLS-Test...")

    // Einer der echten MX-Server für gmail.com
    val mxHostname = "gmail-smtp-in.l.google.com"
    val port = 25

    var socket: Socket? = null
    try {
        println("📡 Verbinde mit $mxHostname:$port...")
        socket = Socket(mxHostname, port)
        socket.soTimeout = 10000

        val reader = BufferedReader(InputStreamReader(socket.inputStream))
        val writer = PrintWriter(socket.outputStream, true)

        // 1. SMTP Handshake lesen
        println("<- Server sagt: \n" + readSmtpResponse(reader).trim())

        // 2. EHLO senden
        println("-> Sende: EHLO test.local")
        writer.print("EHLO test.local\r\n")
        writer.flush()
        println("<- Server antwortet: \n" + readSmtpResponse(reader).trim())

        // 3. STARTTLS anfordern
        println("-> Sende: STARTTLS")
        writer.print("STARTTLS\r\n")
        writer.flush()
        val startTlsResponse = readSmtpResponse(reader)
        println("<- Server antwortet: \n" + startTlsResponse.trim())

        if (!startTlsResponse.startsWith("220")) {
            println("❌ Server hat STARTTLS abgelehnt.")
            return
        }

        // 4. Socket Upgrade durchführen
        println("🔒 Upgrade auf SSLSocket...")
        val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
        val sslSocket = sslFactory.createSocket(socket, mxHostname, port, true) as SSLSocket

        // WICHTIG: Hostname Verification aktivieren (für MTA-STS essenziell!)
        val sslParams = sslSocket.sslParameters
        sslParams.endpointIdentificationAlgorithm = "HTTPS"
        sslSocket.sslParameters = sslParams

        // 5. Verschlüsselung starten
        sslSocket.startHandshake()
        println("✅ TLS Handshake erfolgreich!")
        println("   Protokoll: ${sslSocket.session.protocol}")
        println("   Cipher: ${sslSocket.session.cipherSuite}")

        // 6. Zertifikatsdaten auslesen
        val certs = sslSocket.session.peerCertificates
        val serverCert = certs[0] as X509Certificate

        println("\n📜 --- ZERTIFIKATSDETAILS ---")
        println("Subject: ${serverCert.subjectX500Principal}")
        println("Issuer: ${serverCert.issuerX500Principal}")
        println("Gültig von: ${serverCert.notBefore}")
        println("Gültig bis: ${serverCert.notAfter}")

        println("SANs (Alternative Namen - wichtig für MTA-STS):")
        serverCert.subjectAlternativeNames?.forEach { entry ->
            if (entry[0] == 2) println(" - ${entry[1]}")
        }
        println("----------------------------\n")

        sslSocket.close()

    } catch (e: Exception) {
        println("❌ FEHLER: ${e.message}")
        e.printStackTrace()
    } finally {
        socket?.close()
        println("🔌 Verbindung beendet.")
    }
}

// Hilfsfunktion zum Lesen der mehrzeiligen SMTP-Antworten
fun readSmtpResponse(reader: BufferedReader): String {
    val response = StringBuilder()
    var line: String?
    while (true) {
        line = reader.readLine() ?: break
        response.append(line).append("\n")
        if (line.length >= 4 && line[3] == ' ') break
    }
    return response.toString()
}